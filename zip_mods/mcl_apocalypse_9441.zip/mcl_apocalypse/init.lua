minetest.register_abm({
    label = "lava_rain",
    nodenames = {"air"},
    interval = 1,
    chance = 100000,
    action = function(pos, node)
        minetest.set_node(pos, {name="mcl_core:lava_source"})
        minetest.check_single_for_falling(pos)
    end
})

minetest.register_abm({
    label = "water_rain",
    nodenames = {"air"},
    interval = 1,
    chance = 100000,
    action = function(pos, node)
        minetest.set_node(pos, {name="mcl_core:water_source"})
        minetest.check_single_for_falling(pos)
    end
})
