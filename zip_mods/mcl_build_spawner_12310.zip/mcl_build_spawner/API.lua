local S = minetest.get_translator(minetest.get_current_modname())

function mcl_build_spawner.register_build(name, desc, tiles)
minetest.register_craftitem(name, {
	description = description,
	inventory_image = tiles,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/name.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 1
			p.x = p.x - 0
			p.z = p.z - 0
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})
end
