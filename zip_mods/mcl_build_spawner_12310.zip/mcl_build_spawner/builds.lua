---------mts/we---------------
---------------length,breadth,height--------
------minetest.place_schematic-------

minetest.register_craftitem("mcl_build_spawner:tower_1", {
	description = "Tower_1",
	inventory_image = "tower.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/tower_1.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 1
			p.x = p.x - 0
			p.z = p.z - 0
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craftitem("mcl_build_spawner:house_1", {
	description = "house_1",
	inventory_image = "house.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/house_1.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 1
			p.x = p.x - 0
			p.z = p.z - 0
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craftitem("mcl_build_spawner:house_2", {
	description = "house_2",
	inventory_image = "house.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/house_2.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 1
			p.x = p.x - 0
			p.z = p.z - 0
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

---------------------------mineclone 2 and 5----------------------------

if minetest.get_modpath("mcl_barrels") then

minetest.register_craftitem("mcl_build_spawner:bakery", {
	description = "bakery",
	inventory_image = "assets.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/bakery(mcl2).we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 1
			p.x = p.x - 0
			p.z = p.z - 0
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craftitem("mcl_build_spawner:bank", {
	description = "bank",
	inventory_image = "assets.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/bank(mcl2).we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 0
			p.x = p.x - 15
			p.z = p.z - 0
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craftitem("mcl_build_spawner:restaurant", {
	description = "restaurant",
	inventory_image = "assets.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/restaurant(mcl2).we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 0
			p.x = p.x - 22
			p.z = p.z - 13
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craftitem("mcl_build_spawner:church", {
	description = "church",
	inventory_image = "assets.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/church(mcl2).we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 0
			p.x = p.x - 12
			p.z = p.z - 10
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})
end

if not minetest.get_modpath("mcl_barrels") then

minetest.register_craftitem("mcl_build_spawner:bakery", {
	description = "bakery",
	inventory_image = "assets.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/bakery(mcl5).we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 1
			p.x = p.x - 0
			p.z = p.z - 0
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craftitem("mcl_build_spawner:bank", {
	description = "bank",
	inventory_image = "assets.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/bank(mcl5).we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 0
			p.x = p.x - 15
			p.z = p.z - 0
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craftitem("mcl_build_spawner:restaurant", {
	description = "restaurant",
	inventory_image = "assets.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/restaurant(mcl5).we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 0
			p.x = p.x - 22
			p.z = p.z - 13
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craftitem("mcl_build_spawner:church", {
	description = "church",
	inventory_image = "assets.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/church(mcl5).we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 0
			p.x = p.x - 12
			p.z = p.z - 10
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})
end



---------------------------------------------------


-------mcl_decor-------

if minetest.get_modpath("mcl_decors") then
	
minetest.register_craftitem("mcl_build_spawner:extra_house_1", {
	description = "extra_house_1",
	inventory_image = "house.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("mcl_build_spawner").."/schemes/extra_house_1.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.y = p.y - 1
			p.x = p.x - 0
			p.z = p.z - 0
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})
end
