mcl_build_spawner = {}

local modpath = minetest.get_modpath("mcl_build_spawner")

-- Load files

dofile(modpath .. "/builds.lua")
--dofile(modpath .. "/API.lua")--
