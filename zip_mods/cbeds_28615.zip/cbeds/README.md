# Hardware colored beds

This mod adds beds in all colors of the vanilla wool mod. For VoxeLibre and Mineclonia it makes the already existing colored beds adhere to the texture format.

This way texture pack creators only need to provide 12 square standard size textures and get nice colored beds (bottom node, top node, inventory item) across many games while maintaining full creative freedom in regards to their appearance. It's also much **easier to texture** than the .obj of VoxeLibre or the all the variants colorful_beds provides!

These beds are **metric compatible** with the biggest implementor of colored beds which is VoxeLibre and at the same time share the boundary boxes of the MTG simple beds. This means textures created for them only need to be adjusted.

Existing vanilla beds are replaced with red beds and existing beds from colorful_beds mod are replaced with their respective color.
The crafting recipes for vanilla beds are removed because they don't exist anymore due to the alias.

**This uses much less RAM** than other colored bed implementations because it has base textures and colored textures rather than two fully textured nodes and one inventory item for each bed color. That's at most 2/15 of colorful beds and 2/16 of VoxeLibre beds.

As you can see from the screenshots, I've already made my own texture pack compatible with this. (Hand Painted Expanded)