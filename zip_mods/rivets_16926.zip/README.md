Rivets
======

This mod adds rivets made of various metals.
Rivets can be placed on the surface of a block, preventing the block from being broken or moved.

Contents:

- Steel Rivet (Minetest Game, Repixture)
- Bronze Rivet (Minetest Game, Repixture)
- Wrought Iron Rivet (Repixture)
- Carbon Steel Rivet (Repixture)
- Iron Rivet (MineClone)
- Netherite Rivet (MineClone)
- Brass Rivet (Basic Materials)
- Titanium Rivet (Titanium)


License
-------

Rivets by Silver Sandstone <@SilverSandstone@craftodon.social>
Created in 2023 and dedicated to the public domain via CC0.

See `LICENSE.md` for more information.
