Rivets License
==============

License of Code
---------------

Written in 2023 by Silver Sandstone <@SilverSandstone@craftodon.social>

To the extent possible under law, the author has dedicated all copyright
and related and neighbouring rights to this software to the public
domain worldwide. This software is distributed without any warranty.

You should have received a copy of the CC0 Public Domain Dedication
along with this software. If not, see
<https://creativecommons.org/publicdomain/zero/1.0/>.


License of Assets
-----------------

Rivet textures made by [Silver Sandstone] using GIMP,
based on `017.png` from [50 free textures] by [rubberduck],
dedicated to the public domain via [Creative Commons Zero 1.0].

Rivet models made by [Silver Sandstone] using Blockbench,
dedicated to the public domain via [Creative Commons Zero 1.0].


[Silver Sandstone]:             https://content.minetest.net/users/SilverSandstone/     "Silver Sandstone on Minetest ContentDB"
[rubberduck]:                   https://opengameart.org/users/rubberduck                "rubberduck on OpenGameArt.org"
[50 free textures]:             https://opengameart.org/content/50-free-textures        "50 free textures on OpenGameArt.org"
[Creative Commons Zero 1.0]:    http://creativecommons.org/publicdomain/zero/1.0/       "Creative Commons Zero 1.0"
