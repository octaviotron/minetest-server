minetest.register_node("mcl_spikes:wooden_spike", {
	description           = "Wooden spikes",
	damage_per_second     = 2,
	drawtype              = "firelike",
	groups                = {deco_block=1, choppy=3, flammable=3},
	walkable              = false,
	buildable_to          = true,
	_mcl_hardness         = 1.0,
	_mcl_blast_resistance = 1.0,
	tiles                 = {"mcl_spikes_wooden_spike.png"},
})

minetest.register_craft({
	type   = "shapeless",
	output = "mcl_spikes:wooden_spike",
	recipe = {
		"group:stick", "group:stick", "group:stick",
		"group:wood",  "group:wood",  "group:wood"
	}
})

-------------------------------------------------------------------------------

minetest.register_node("mcl_spikes:iron_spike", {
	description           = "Iron spikes",
	damage_per_second     = 4,
	drawtype              = "firelike",
	groups                = {deco_block=1, pickaxey=1, material_stone=1},
	walkable              = false,
	buildable_to          = true,
	_mcl_hardness         = 2.5,
	_mcl_blast_resistance = 3.5,
	tiles                 = {"mcl_spikes_iron_spike.png"},
})

minetest.register_craft({
	type   = "shapeless",
	output = "mcl_spikes:iron_spike",
	recipe = {
		"mcl_core:iron_nugget", "mcl_core:iron_nugget", "mcl_core:iron_nugget",
		"mcl_core:iron_ingot",  "mcl_core:iron_ingot",  "mcl_core:iron_ingot"
	}
})

-------------------------------------------------------------------------------

minetest.register_node("mcl_spikes:diamond_spike", {
	description           = "Diamond spikes",
	damage_per_second     = 20,
	drawtype              = "firelike",
	groups                = {deco_block=1, pickaxey=1, material_stone=1},
	walkable              = false,
	buildable_to          = true,
	_mcl_hardness         = 2.5,
	_mcl_blast_resistance = 3.5,
	tiles                 = {"mcl_spikes_diamond_spike.png"},
})

minetest.register_craft({
	type   = "shapeless",
	output = "mcl_spikes:diamond_spike",
	recipe = {
		"mcl_core:diamond",     "mcl_core:diamond",     "mcl_core:diamond",
		"mcl_core:iron_ingot",  "mcl_core:iron_ingot",  "mcl_core:iron_ingot"
	}
})
