-- coins
-- coin mod for VL and VL-derivatives

local modpath = minetest.get_modpath("kmdev_coins")

dofile(modpath .. "/craftitems.lua")
-- dofile(modpath .. "/nodes.lua")
dofile(modpath .. "/recipes.lua")

-- check if certain mods exist
ElepowerExists = false
ITExists = false -- IndustrialTest

if core.get_modpath('elepower') then
    ElepowerExists = true
end

if core.get_modpath('industrialtest') then
    ITExists = true
end
