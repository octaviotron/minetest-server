# Coins
![Coins screenshot](screenshot_20260307_190056.png "coins screenshot")

A coin mod for Luanti

comes in denominations of **1**, **5**, **20**, **50**, and **100** units

# Crafting
coins are crafted by putting the **Hammer** with various plates that are made out of certain minerals in a crafting grid.
the plates are crafted by putting a **Hammer** with the respective mineral in a crafting grid. Both the recipes are shapeless.

The metal plates used in the crafting recipes varies with the coin you want to craft.
- **Copper Plate** -> 1 Unit Coin
- **Iron/ Silver Plate** -> 5 Unit Coin
    - if a compatible mod containing silver is found, such as `elepower`, this will be used instead of iron.
- **Gold Plate** -> 20 Unit Coin
- **Emerald Plate** -> 50 Unit Coin
- **Diamond Plate** -> 100 Unit Coin

# Mod compatibility
Currently, the only mods with support are `elepower` and `industrialtest`.

The mod compatibility in this mod only extends to the plates used to craft the individual coins. The Hammer may be included in this as well. If a mod with matching plates are found, such as `elepower`, those plates will replace the ones from this mod.

In addition to the behaviour above, if there are multiple mods that add plates, one will not overwrite another, but there will simply be more recipes offered.
