-- recipes for the plates (only if they don't exits)

if not ElepowerExists then
    -- 1 unit
    core.register_craft({
        type = "shapeless",
        output = "kmdev_coins:copepr_plate",
        recipe = {
            "mcl_copper:copper_ingot",
            "kmdev_coins:hammer",
        },
    })

    -- 5 unit (but only if silver isn't available)
    core.register_craft({
        type = "shapeless",
        output = "kmdev_coins:iron_plate",
        recipe = {
            "mcl_core:iron_ingot",
            "kmdev_coins:hammer",
        },
    })


    -- 20 units
    core.register_craft({
        type = "shapeless",
        output = "kmdev_coins:gold_plate",
        recipe = {
            "mcl_core:gold_ingot",
            "kmdev_coins:hammer",
        },
    })

    -- 100 units
    core.register_craft({
        type = "shapeless",
        output = "kmdev_coins:diamond_plate",
        recipe = {
            "mcl_core:diamond",
            "kmdev_coins:hammer",
        },
    })
end

-- 50 units
core.register_craft({
    type = "shapeless",
    output = "kmdev_coins:emerald_plate",
    recipe = {
        "mcl_core:emerald",
        "kmdev_coins:hammer",
    },
})

-- hammer
core.register_craft({
    output = "kmdev_coins:hammer",
    recipe = {
        { "mcl_core:iron_ingot", "",               "" },
        { "",                    "mcl_core:stick", "" },
        { "",                    "",               "mcl_core:stick" }
    }
})

-- kmdev_coins
-- use an array so it is easier to add compatibility for other mods
local compatibleMods_1u = {}           -- copper
local compatibleMods_5u = {}           -- iron/ silver
local compatibleMods_20u = {}          --gold
local compatibleMods_50u = { "kmdev_coins" } -- emerald
local compatibleMods_100u = {}         -- diamond

if ElepowerExists then
    compatibleMods_1u[# compatibleMods_1u + 1] = "elepower_dymanics"
    compatibleMods_5u[# compatibleMods_5u + 1] = "elepower_dymanics"
    compatibleMods_20u[# compatibleMods_20u + 1] = "elepower_dymanics"
    compatibleMods_100u[# compatibleMods_100u + 1] = "elepower_dymanics"
elseif ITExists then
    compatibleMods_1u[# compatibleMods_1u + 1] = 'industrialtest'
    compatibleMods_5u[# compatibleMods_5u + 1] = 'industrialtest'
else
    if #compatibleMods_1u == 0 then
        compatibleMods_1u[# compatibleMods_1u + 1] = "kmdev_coins"
    end

    if #compatibleMods_5u == 0 then
        compatibleMods_5u[# compatibleMods_5u + 1] = "kmdev_coins"
    end

    if #compatibleMods_20u == 0 then
        compatibleMods_20u[# compatibleMods_20u + 1] = "kmdev_coins"
    end

    if #compatibleMods_50u == 0 then
        compatibleMods_50u[# compatibleMods_50u + 1] = "kmdev_coins"
    end

    if #compatibleMods_100u == 0 then
        compatibleMods_100u[# compatibleMods_100u + 1] = "kmdev_coins"
    end
end

-- register the recipes
-- 1 unit
for i, mod in ipairs(compatibleMods_1u) do
    core.register_craft({
        type = "shapeless",
        output = "kmdev_coins:1_unit_coin",
        recipe = {
            mod .. ":copper_plate",
            "kmdev_coins:hammer"
        }
    })
end

-- 5 unit
for i, mod in ipairs(compatibleMods_5u) do
    if mod == "elepower_dymanics" then
        core.register_craft({
            type = "shapeless",
            output = "kmdev_coins:5_unit_coin",
            recipe = {
                "elepower_dymanics:silver_plate",
                "kmdev_coins:hammer"
            }
        })
    else
        core.register_craft({
            type = "shapeless",
            output = "kmdev_coins:5_unit_coin",
            recipe = {
                mod .. ":iron_plate",
                "kmdev_coins:hammer"
            }
        })
    end
end

-- 20 unit
for i, mod in ipairs(compatibleMods_20u) do
    core.register_craft({
        type = "shapeless",
        output = "kmdev_coins:20_unit_coin",
        recipe = {
            mod .. ":gold_plate",
            "kmdev_coins:hammer"
        }
    })
end

-- 50 unit
for i, mod in ipairs(compatibleMods_50u) do
    core.register_craft({
        type = "shapeless",
        output = "kmdev_coins:50_unit_coin",
        recipe = {
            mod .. ":emerald_plate",
            "kmdev_coins:hammer"
        }
    })
end

-- 100 unit
for i, mod in ipairs(compatibleMods_100u) do
    core.register_craft({
        type = "shapeless",
        output = "kmdev_coins:100_unit_coin",
        recipe = {
            mod .. ":diamond_plate",
            "kmdev_coins:hammer"
        }
    })
end
