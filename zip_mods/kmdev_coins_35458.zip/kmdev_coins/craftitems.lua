core.register_craftitem("kmdev_coins:1_unit_coin", {
    description = "1 Unit Coin",
    inventory_image = "kmdev_coins_1_unit.png"
})

core.register_craftitem("kmdev_coins:5_unit_coin", {
    description = "5 Unit Coin",
    inventory_image = "kmdev_coins_5_unit.png"
})

core.register_craftitem("kmdev_coins:20_unit_coin", {
    description = "20 Unit Coin",
    inventory_image = "kmdev_coins_20_unit.png"
})

core.register_craftitem("kmdev_coins:50_unit_coin", {
    description = "50 Unit Coin",
    inventory_image = "kmdev_coins_50_unit.png"
})

core.register_craftitem("kmdev_coins:100_unit_coin", {
    description = "100 Unit Coin",
    inventory_image = "kmdev_coins_100_unit.png"
})

-- the following will only be here for compatibility
core.register_craftitem("kmdev_coins:hammer", {
    description = "Hammer\nUsed to turn various minerals into their respective plates",
    inventory_image = "kmdev_coins_hammer.png"
})

core.register_craftitem("kmdev_coins:copper_plate", {
    description = "Copper Plate\nUse with a Hammer in the crafting grid to turn into coin",
    inventory_image = "kmdev_coins_copper_plate.png"
})

core.register_craftitem("kmdev_coins:iron_plate", {
    description = "Iron Plate\nUse with a Hammer in the crafting grid to turn into coin",
    inventory_image = "kmdev_coins_iron_plate.png"
})

core.register_craftitem("kmdev_coins:gold_plate", {
    description = "Gold Plate\nUse with a Hammer in the crafting grid to turn into coin",
    inventory_image = "kmdev_coins_gold_plate.png"
})

core.register_craftitem("kmdev_coins:emerald_plate", {
    description = "Emerald Plate\nUse with a Hammer in the crafting grid to turn into coin",
    inventory_image = "kmdev_coins_emerald_plate.png"
})

core.register_craftitem("kmdev_coins:diamond_plate", {
    description = "Diamond Plate\nUse with a Hammer in the crafting grid to turn into coin",
    inventory_image = "kmdev_coins_diamond_plate.png"
})
