# Coins - Adds coins in to the game

Source Code: Copyright (C) 2026 kmdev - LGPL v3

Textures: Copyright (C) 2026 kmdev - CC-BY-SA v4
