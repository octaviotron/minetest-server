Deepslate
=========

[ContentDB](https://content.minetest.net/packages/SilverSandstone/deepslate/)

This mod adds deepslate and related building materials.

Deepslate is a type of stone that can be found deep underground.
It can be crafted into bricks, blocks, tiles, and pillars for building, or
used in place of stone when crafting tools.

Ores and dungeons in the deepslate layer will generate as deepslate variants.

By default, deepslate starts generating below -768, and replaces all stone
below -1024. This can be changed in the settings.


Contents
--------

- Deepslate
- Cobbled Deepslate
- Deepslate Brick
- Cracked Deepslate Brick
- Deepslate Block (Polished Deepslate in MineClone)
- Chiselled Deepslate
- Deepslate Tiles
- Cracked Deepslate Tiles
- Deepslate Pillar
- Deepslate variants of ores


Compatible Games and Mods
-------------------------

Games:

- Minetest Game and derivatives (Dreambuilder, Mesecraft, VoxelGarden, Survivetest, etc.)
- MineClone (integrates into mcl_deepslate, providing only additional features.)
- Repixture

Ores from these mods:

- Blox
- Ethereal
- Glooptest
- Lapis Lazuli
- Legendary Ore
- Magic Materials
- More Ores
- Quartz
- Rainbow Ore
- Silver
- Technic
- Techage
- Titanium
- Zinc

Shapes and variants from these mods:

- Advanced Trains
- Castle Masonry
- Rocks
- Stairs+ (More Blocks)
- Stairs Redo


License
-------

Code by [Silver Sandstone](https://content.minetest.net/users/SilverSandstone/),
licensed under the MIT license.

Assets from [Pixel Perfection Legacy](https://www.planetminecraft.com/texture-pack/pixel-perfection-chorus-edit/)
by XSSheep, freejusticehere, and Nova_Wostra, with modifications by Silver Sandstone,
licensed under the [Creative Commons Attribution-ShareAlike 4.0 International](http://creativecommons.org/licenses/by-sa/4.0/deed.en) license.

See `LICENSE.md` for more information.
